Welcome to Stress Test
created by Benjamin Dagg in Aug, 2018

########## Installation ##############
1. download StressTest.zip
2. extract to folder
3. run StressTest.exe